package controllers.mockups;

import models.mockups.Mockup;
import play.exceptions.UnexpectedException;
import play.mvc.Http;
import play.mvc.results.Result;

import java.util.Map;

public class RenderMockup extends Result {

    private boolean showRibbon;
    private Mockup mockup;
    private Map<String, Object> data;

    public RenderMockup(Mockup mockup, boolean showRibbon, Map<String, Object> data) {
        this.mockup = mockup;
        this.data = data;
        this.showRibbon = showRibbon;
    }

    public void apply(Http.Request request, Http.Response response) {
        try {
            response.out.write(mockup.getContent(showRibbon, data).getBytes(getEncoding()));
            setContentTypeIfNotSet(response, mockup.getContentType());
        } catch (Exception e) {
            throw new UnexpectedException(e);
        }
    }


}
